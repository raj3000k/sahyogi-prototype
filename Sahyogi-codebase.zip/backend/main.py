from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Sahyogi API", version="0.1.0")

class AskRequest(BaseModel):
    question: str
    sahyogi_id: str = "raj"

@app.get("/health")
def health():
    return {"status": "ok", "service": "sahyogi-api"}

@app.post("/ask")
def ask_sahyogi(request: AskRequest):
    return {
        "answer": f"Sahyogi received: {request.question}",
        "sources": ["demo-context/merchant-onboarding.md"],
        "mode": "demo"
    }
