"use client";

import { useMemo, useState } from "react";

type Tab = "home" | "people" | "continuity" | "collective";

const teammates = [
  { name: "Aarav Mehta", role: "Product Lead", initials: "AM", color: "violet", status: "Online", knowledge: "87%", focus: "UPI growth & merchant onboarding" },
  { name: "Meera Nair", role: "Engineering Lead", initials: "MN", color: "orange", status: "Away · PTO", knowledge: "93%", focus: "Payments reliability & APIs" },
  { name: "Kabir Shah", role: "Risk Analyst", initials: "KS", color: "green", status: "Online", knowledge: "78%", focus: "Fraud controls & compliance" }
];

export default function Home() {
  const [tab, setTab] = useState<Tab>("home");
  const [prompt, setPrompt] = useState("");
  const [reply, setReply] = useState("I’m ready to help. Ask about a project, a teammate’s context, or start a continuity handover.");
  const [merging, setMerging] = useState(false);
  const [handoff, setHandoff] = useState(false);
  const title = useMemo(() => ({ home: "Good morning, Raj.", people: "Your Sahyogis", continuity: "Continuity centre", collective: "Collective intelligence" })[tab], [tab]);

  function askSahyogi() {
    if (!prompt.trim()) return;
    setReply(`Based on your approved workspace context: ${prompt} — I found the latest ownership, decisions, and next actions. I can package this as a concise brief for the right teammate.`);
    setPrompt("");
  }

  return <main className="shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark">S</span><span>SAHYOGI</span></div>
      <div className="workspace"><span className="dot" />Paytm Innovation Lab <span className="chevron">⌄</span></div>
      <nav>
        {([ ["home", "⌂", "Home"], ["people", "◉", "Sahyogis"], ["continuity", "↹", "Continuity"], ["collective", "✦", "Collective"] ] as const).map(([key, icon, label]) => <button key={key} onClick={() => setTab(key)} className={tab === key ? "active" : ""}><span>{icon}</span>{label}</button>)}
      </nav>
      <div className="sidebar-bottom"><button><span>?</span>Help centre</button><div className="you"><span className="avatar small">RM</span><div><b>Raj Motwani</b><small>Product team</small></div><span>⋮</span></div></div>
    </aside>

    <section className="content">
      <header><div><p className="eyebrow">THURSDAY, 18 SEPTEMBER</p><h1>{title}</h1></div><div className="header-actions"><button className="icon-button">⌕</button><button className="icon-button notification">♧</button><button className="new-button" onClick={() => setTab("people")}>+ New Sahyogi</button></div></header>

      {tab === "home" && <>
        <section className="hero"><div className="hero-copy"><span className="pill">✦ YOUR DIGITAL TEAMMATE</span><h2>Work never loses its <em>context.</em></h2><p>Capture what matters today, so your team can move confidently tomorrow.</p><div className="ask"><span className="spark">✦</span><input value={prompt} onChange={(e) => setPrompt(e.target.value)} onKeyDown={(e) => e.key === "Enter" && askSahyogi()} placeholder="Ask your Sahyogi anything…" /><button onClick={askSahyogi}>↑</button></div><p className="reply">{reply}</p></div><div className="orb-wrap"><div className="orb glow-one"/><div className="orb glow-two"/><div className="orb-core">S</div><span className="orbit orbit-a">✦</span><span className="orbit orbit-b">✦</span></div></section>
        <section className="metrics"><div><span className="metric-icon purple">▣</span><p>Context captured</p><b>24 <small>items this week</small></b></div><div><span className="metric-icon gold">↝</span><p>Active handovers</p><b>{handoff ? "2" : "1"} <small>needs attention</small></b></div><div><span className="metric-icon mint">✦</span><p>Team readiness</p><b>91% <small>↑ 6% this month</small></b></div></section>
        <section className="grid"><div className="panel context"><div className="panel-head"><div><p className="eyebrow">YOUR MEMORY</p><h3>Recent context</h3></div><button>View all →</button></div>{["Merchant onboarding Q4 — decision log", "UPI success-rate incident — playbook", "Thursday product sync — key outcomes"].map((x, i) => <div className="context-row" key={x}><span className={`doc d${i}`}>{i === 1 ? "!" : "≡"}</span><div><b>{x}</b><small>{i === 0 ? "Updated 18 min ago · Product" : i === 1 ? "Updated yesterday · Engineering" : "Updated Sep 16 · Meeting"}</small></div><button>⋮</button></div>)}</div>
        <div className="panel handoff"><div className="panel-head"><div><p className="eyebrow">CONTINUITY RADAR</p><h3>One handover needs you</h3></div><span className="alert">Action needed</span></div><div className="handoff-person"><span className="avatar orange">MN</span><div><b>Meera is away next week</b><small>Engineering Lead · 5 days</small></div></div><p>Her Sahyogi has prepared a handover for <b>Payments reliability</b>, but needs your review of two open decisions.</p><button className="primary" onClick={() => { setHandoff(true); setTab("continuity"); }}>Review handover <span>→</span></button></div></section>
      </>}

      {tab === "people" && <section className="page-panel"><p className="eyebrow">TEAM DIRECTORY</p><h2>Every expert has a Sahyogi.</h2><p className="sub">Living, permissioned context that stays with the team—not just one person.</p><div className="people-grid">{teammates.map(t => <article className="person" key={t.name}><div className="person-top"><span className={`avatar ${t.color}`}>{t.initials}</span><span className={t.status.startsWith("Online") ? "status online" : "status away"}>{t.status}</span></div><h3>{t.name}</h3><p>{t.role}</p><div className="knowledge"><span>Context readiness</span><b>{t.knowledge}</b><div><i style={{ width: t.knowledge }} /></div></div><small>Focus: {t.focus}</small><button className="secondary" onClick={() => { setReply(`${t.name}'s Sahyogi is open. It can answer within its approved project context.`); setTab("home"); }}>Open Sahyogi →</button></article>)}</div></section>}

      {tab === "continuity" && <section className="page-panel continuity"><p className="eyebrow">GUIDED HANDOVER</p><h2>Meera’s continuity brief</h2><p className="sub">Her Sahyogi distilled active work, decisions and people who can unblock it.</p><div className="brief"><div><span className="step done">✓</span><b>Current ownership captured</b><small>3 systems, 6 recurring decisions, 4 key contacts</small></div><div><span className="step done">✓</span><b>Open work mapped</b><small>2 launch blockers and 1 reliability investigation</small></div><div><span className="step">3</span><b>Your decision requested</b><small>Confirm fallback owner for merchant rollback policy</small><button className="primary compact" onClick={() => setHandoff(true)}>{handoff ? "Review recorded ✓" : "Review decision"}</button></div></div></section>}

      {tab === "collective" && <section className="page-panel collective"><p className="eyebrow">CROSS-FUNCTIONAL MODE</p><h2>Assemble the right expertise.</h2><p className="sub">Sahyogis retain their owners’ permissions and bring only relevant approved context.</p><div className="merge-stage"><div className="merge-members"><span className="avatar violet">AM</span><span className="plus">+</span><span className="avatar orange">MN</span><span className="plus">+</span><span className="avatar green">KS</span></div><div className="merge-copy"><h3>{merging ? "Launch brief ready" : "Merchant growth launch squad"}</h3><p>{merging ? "A shared brief connects product, reliability and risk constraints with cited sources." : "Combine Product, Engineering and Risk context to prepare a launch-ready recommendation."}</p><button className="primary" onClick={() => setMerging(true)}>{merging ? "Open shared brief →" : "Merge Sahyogis ✦"}</button></div></div>{merging && <div className="result"><span>✦</span><div><b>3 perspectives synthesized</b><p>Recommended path: phased pilot for 500 merchants, with automated rollback guardrails and a pre-approved risk threshold.</p></div></div>}</section>}
    </section>
  </main>;
}
